<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Driver;
use App\Models\Medic;
use App\Models\Ambulance;
use App\Models\DriverMedicPairing;
use App\Models\DriverAmbulancePairing;
use App\Models\PairingLog;

class PairingController extends Controller
{
    public function index(Request $request)
    {
        $query = DriverMedicPairing::with(['driver', 'medic'])
            ->where('status', 'active');
            
        $ambulanceQuery = DriverAmbulancePairing::with(['driver', 'ambulance'])
            ->where('status', 'active');
        
        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->whereHas('driver', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            })->orWhereHas('medic', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
            
            $ambulanceQuery->whereHas('driver', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            })->orWhereHas('ambulance', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }
        
        
        // Filter by driver
        if ($request->filled('driver_id')) {
            $query->where('driver_id', $request->driver_id);
            $ambulanceQuery->where('driver_id', $request->driver_id);
        }
        
        $driverMedicPairings = $query->orderBy('pairing_date', 'desc')->get();
        $driverAmbulancePairings = $ambulanceQuery->orderBy('pairing_date', 'desc')->get();
        
        // Group driver-medic pairings by driver and date for better display
        $groupedDriverMedicPairings = $driverMedicPairings->groupBy(function($pairing) {
            return $pairing->driver_id . '_' . $pairing->pairing_date->format('Y-m-d');
        });
        
        // Group driver-ambulance pairings by driver and date for better display
        $groupedDriverAmbulancePairings = $driverAmbulancePairings->groupBy(function($pairing) {
            return $pairing->driver_id . '_' . $pairing->pairing_date->format('Y-m-d');
        });
        
        // Get drivers and medics for filter dropdowns
        $drivers = Driver::where('status', 'active')->get();
        $medics = Medic::where('status', 'active')->get();
        
        return view('admin.pairing.index', compact('driverMedicPairings', 'driverAmbulancePairings', 'groupedDriverMedicPairings', 'groupedDriverAmbulancePairings', 'drivers', 'medics'));
    }

    public function createDriverMedicPairing(Request $request)
    {
        $drivers = Driver::where('status', 'active')->get();
        $medics = Medic::where('status', 'active')->get();
        
        // Get already paired drivers and medics for the selected date
        $selectedDate = $request->get('pairing_date', date('Y-m-d'));
        $pairedDrivers = DriverMedicPairing::where('pairing_date', $selectedDate)
            ->where('status', 'active')
            ->pluck('driver_id')
            ->unique()
            ->toArray();
        $pairedMedics = DriverMedicPairing::where('pairing_date', $selectedDate)
            ->where('status', 'active')
            ->pluck('medic_id')
            ->unique()
            ->toArray();
        
        return view('admin.pairing.create-driver-medic', compact('drivers', 'medics', 'pairedDrivers', 'pairedMedics', 'selectedDate'));
    }

    public function storeDriverMedicPairing(Request $request)
    {
        $request->validate([
            'driver_id' => 'required|exists:drivers,id',
            'medic_id' => 'required|exists:medics,id',
            'pairing_date' => 'required|date',
            'start_time' => 'nullable|date_format:H:i',
            'end_time' => 'nullable|date_format:H:i|after:start_time',
            'notes' => 'nullable|string|max:500',
        ]);

        // Check for existing pairings
        // Check if medic is already paired with a different driver
        $existingMedicPairing = DriverMedicPairing::where('medic_id', $request->medic_id)
            ->where('pairing_date', $request->pairing_date)
            ->where('status', 'active')
            ->where('driver_id', '!=', $request->driver_id)
            ->first();

        if ($existingMedicPairing) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['medic_id' => 'This medic is already paired with another driver on this date.']);
        }

        // Check if driver is already paired with a different team (different medics)
        $existingDriverPairing = DriverMedicPairing::where('driver_id', $request->driver_id)
            ->where('pairing_date', $request->pairing_date)
            ->where('status', 'active')
            ->where('medic_id', '!=', $request->medic_id)
            ->first();

        if ($existingDriverPairing) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['driver_id' => 'This driver is already paired with a different team on this date.']);
        }

        $pairing = DriverMedicPairing::create($request->all());

        // Log the creation
        $this->logPairingAction('driver_medic', $pairing->id, 'created', null, $pairing->toArray());

        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Medic pairing created successfully!');
    }

    public function createDriverAmbulancePairing(Request $request)
    {
        $drivers = Driver::where('status', 'active')->get();
        $ambulances = Ambulance::all();
        
        // Get already paired drivers and ambulances for the selected date
        $selectedDate = $request->get('pairing_date', date('Y-m-d'));
        $pairedDrivers = DriverAmbulancePairing::where('pairing_date', $selectedDate)
            ->where('status', 'active')
            ->pluck('driver_id')
            ->unique()
            ->toArray();
        $pairedAmbulances = DriverAmbulancePairing::where('pairing_date', $selectedDate)
            ->where('status', 'active')
            ->pluck('ambulance_id')
            ->unique()
            ->toArray();
        
        return view('admin.pairing.create-driver-ambulance', compact('drivers', 'ambulances', 'pairedDrivers', 'pairedAmbulances', 'selectedDate'));
    }

    public function storeDriverAmbulancePairing(Request $request)
    {
        $request->validate([
            'driver_id' => 'required|exists:drivers,id',
            'ambulance_id' => 'required|exists:ambulances,id',
            'pairing_date' => 'required|date',
            'notes' => 'nullable|string|max:500',
        ]);

        // Check for existing pairings
        // Check if ambulance is already paired with a different driver
        $existingAmbulancePairing = DriverAmbulancePairing::where('ambulance_id', $request->ambulance_id)
            ->where('pairing_date', $request->pairing_date)
            ->where('status', 'active')
            ->where('driver_id', '!=', $request->driver_id)
            ->first();

        if ($existingAmbulancePairing) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['ambulance_id' => 'This ambulance is already paired with another driver on this date.']);
        }

        // Check if driver is already paired with a different ambulance
        $existingDriverPairing = DriverAmbulancePairing::where('driver_id', $request->driver_id)
            ->where('pairing_date', $request->pairing_date)
            ->where('status', 'active')
            ->where('ambulance_id', '!=', $request->ambulance_id)
            ->first();

        if ($existingDriverPairing) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['driver_id' => 'This driver is already paired with another ambulance on this date.']);
        }

        $pairing = DriverAmbulancePairing::create($request->all());

        // Log the creation
        $this->logPairingAction('driver_ambulance', $pairing->id, 'created', null, $pairing->toArray());

        // Sync driver's current ambulance assignment for active pairing
        $driver = Driver::find($pairing->driver_id);
        if ($driver && $pairing->status === 'active') {
            $driver->ambulance_id = $pairing->ambulance_id;
            $driver->save();
        }

        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Ambulance pairing created successfully!');
    }

    public function editDriverMedicPairing($id)
    {
        $pairing = DriverMedicPairing::with(['driver', 'medic'])->findOrFail($id);
        $drivers = Driver::where('status', 'active')->get();
        $medics = Medic::where('status', 'active')->get();
        
        return view('admin.pairing.edit-driver-medic', compact('pairing', 'drivers', 'medics'));
    }

    public function updateDriverMedicPairing(Request $request, $id)
    {
        $pairing = DriverMedicPairing::findOrFail($id);

        $request->validate([
            'driver_id' => 'required|exists:drivers,id',
            'medic_id' => 'required|exists:medics,id',
            'pairing_date' => 'required|date',
            'start_time' => 'nullable|date_format:H:i',
            'end_time' => 'nullable|date_format:H:i|after:start_time',
            'status' => 'required|in:active,completed,cancelled',
            'notes' => 'nullable|string|max:500',
        ]);

        $oldData = $pairing->toArray();
        $pairing->update($request->all());

        // Log the update
        $this->logPairingAction('driver_medic', $pairing->id, 'updated', $oldData, $pairing->fresh()->toArray());

        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Medic pairing updated successfully!');
    }

    public function editDriverAmbulancePairing($id)
    {
        $pairing = DriverAmbulancePairing::with(['driver', 'ambulance'])->findOrFail($id);
        $drivers = Driver::where('status', 'active')->get();
        $ambulances = Ambulance::all();
        
        return view('admin.pairing.edit-driver-ambulance', compact('pairing', 'drivers', 'ambulances'));
    }

    public function updateDriverAmbulancePairing(Request $request, $id)
    {
        $pairing = DriverAmbulancePairing::findOrFail($id);

        $request->validate([
            'driver_id' => 'required|exists:drivers,id',
            'ambulance_id' => 'required|exists:ambulances,id',
            'pairing_date' => 'required|date',
            'status' => 'required|in:active,completed,cancelled',
            'notes' => 'nullable|string|max:500',
        ]);

        $oldData = $pairing->toArray();
        $pairing->update($request->all());

        // Log the update
        $this->logPairingAction('driver_ambulance', $pairing->id, 'updated', $oldData, $pairing->fresh()->toArray());

        // If pairing remains active, sync driver's ambulance; if not, clear if pointing to this ambulance
        $pairing = $pairing->fresh();
        $driver = Driver::find($pairing->driver_id);
        if ($driver) {
            if ($pairing->status === 'active') {
                $driver->ambulance_id = $pairing->ambulance_id;
                $driver->save();
            } else if ($driver->ambulance_id === $pairing->ambulance_id) {
                $driver->ambulance_id = null;
                $driver->save();
            }
        }

        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Ambulance pairing updated successfully!');
    }

    public function destroyDriverMedicPairing($id)
    {
        $pairing = DriverMedicPairing::findOrFail($id);
        $oldData = $pairing->toArray();
        $pairing->delete();

        // Log the deletion
        $this->logPairingAction('driver_medic', $id, 'deleted', $oldData, null);

        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Medic pairing deleted successfully!');
    }

    public function destroyDriverAmbulancePairing($id)
    {
        $pairing = DriverAmbulancePairing::findOrFail($id);
        $oldData = $pairing->toArray();
        $pairing->delete();

        // Log the deletion
        $this->logPairingAction('driver_ambulance', $id, 'deleted', $oldData, null);

        // Clear driver's ambulance if it points to this deleted pairing
        $driver = Driver::find($oldData['driver_id'] ?? null);
        if ($driver && $driver->ambulance_id === ($oldData['ambulance_id'] ?? null)) {
            $driver->ambulance_id = null;
            $driver->save();
        }
        
        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Ambulance pairing deleted successfully!');
    }

    public function completeDriverMedicPairing($id)
    {
        $pairing = DriverMedicPairing::findOrFail($id);
        $oldData = $pairing->toArray();
        
        $pairing->update(['status' => 'completed']);
        
        // Log the completion
        $this->logPairingAction('driver_medic', $pairing->id, 'completed', $oldData, $pairing->fresh()->toArray());
        
        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Medic pairing marked as completed!');
    }

    public function cancelDriverMedicPairing($id)
    {
        $pairing = DriverMedicPairing::findOrFail($id);
        $oldData = $pairing->toArray();
        
        $pairing->update(['status' => 'cancelled']);
        
        // Log the cancellation
        $this->logPairingAction('driver_medic', $pairing->id, 'cancelled', $oldData, $pairing->fresh()->toArray());
        
        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Medic pairing cancelled!');
    }

    public function completeDriverAmbulancePairing($id)
    {
        $pairing = DriverAmbulancePairing::findOrFail($id);
        $oldData = $pairing->toArray();
        
        $pairing->update(['status' => 'completed']);
        
        // Log the completion
        $this->logPairingAction('driver_ambulance', $pairing->id, 'completed', $oldData, $pairing->fresh()->toArray());

        // Clear driver's ambulance if it points to this completed pairing
        $driver = Driver::find($pairing->driver_id);
        if ($driver && $driver->ambulance_id === $pairing->ambulance_id) {
            $driver->ambulance_id = null;
            $driver->save();
        }
        
        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Ambulance pairing marked as completed!');
    }

    public function cancelDriverAmbulancePairing($id)
    {
        $pairing = DriverAmbulancePairing::findOrFail($id);
        $oldData = $pairing->toArray();
        
        $pairing->update(['status' => 'cancelled']);
        
        // Log the cancellation
        $this->logPairingAction('driver_ambulance', $pairing->id, 'cancelled', $oldData, $pairing->fresh()->toArray());

        // Clear driver's ambulance if it points to this cancelled pairing
        $driver = Driver::find($pairing->driver_id);
        if ($driver && $driver->ambulance_id === $pairing->ambulance_id) {
            $driver->ambulance_id = null;
            $driver->save();
        }
        
        return redirect()->route('admin.pairing.index')
            ->with('success', 'Driver-Ambulance pairing cancelled!');
    }

    public function pairingLog(Request $request)
    {
        $query = DriverMedicPairing::with(['driver', 'medic'])
            ->whereIn('status', ['completed', 'cancelled']);
            
        $ambulanceQuery = DriverAmbulancePairing::with(['driver', 'ambulance'])
            ->whereIn('status', ['completed', 'cancelled']);
        
        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->whereHas('driver', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            })->orWhereHas('medic', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
            
            $ambulanceQuery->whereHas('driver', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            })->orWhereHas('ambulance', function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }
        
        // Filter by driver
        if ($request->filled('driver_id')) {
            $query->where('driver_id', $request->driver_id);
            $ambulanceQuery->where('driver_id', $request->driver_id);
        }
        
        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
            $ambulanceQuery->where('status', $request->status);
        }
        
        $driverMedicPairings = $query->orderBy('updated_at', 'desc')->get();
        $driverAmbulancePairings = $ambulanceQuery->orderBy('updated_at', 'desc')->get();
        
        // Group driver-medic pairings by driver and date for better display
        $groupedDriverMedicPairings = $driverMedicPairings->groupBy(function($pairing) {
            return $pairing->driver_id . '_' . $pairing->pairing_date->format('Y-m-d');
        });
        
        // Group driver-ambulance pairings by driver and date for better display
        $groupedDriverAmbulancePairings = $driverAmbulancePairings->groupBy(function($pairing) {
            return $pairing->driver_id . '_' . $pairing->pairing_date->format('Y-m-d');
        });
        
        // Get drivers for filter dropdown
        $drivers = Driver::where('status', 'active')->get();
        
        return view('admin.pairing.log', compact('driverMedicPairings', 'driverAmbulancePairings', 'groupedDriverMedicPairings', 'groupedDriverAmbulancePairings', 'drivers'));
    }

    public function bulkPairing(Request $request)
    {
        $drivers = Driver::where('status', 'active')->get();
        $medics = Medic::where('status', 'active')->get();
        $ambulances = Ambulance::all();
        
        // Get already paired medics and ambulances for the selected date
        // Note: We don't mark drivers as "paired" since they can have multiple medics (team concept)
        $selectedDate = $request->get('pairing_date', date('Y-m-d'));
        $pairedMedics = DriverMedicPairing::where('pairing_date', $selectedDate)
            ->where('status', 'active')
            ->pluck('medic_id')
            ->unique()
            ->toArray();
        $pairedAmbulances = DriverAmbulancePairing::where('pairing_date', $selectedDate)
            ->where('status', 'active')
            ->pluck('ambulance_id')
            ->unique()
            ->toArray();
        
        // For drivers, we need to check if they're already paired with medics from a different team
        // This is more complex and will be handled in the validation logic
        $pairedDrivers = []; // We'll handle this in the validation, not in the UI
        
        return view('admin.pairing.bulk', compact('drivers', 'medics', 'ambulances', 'pairedDrivers', 'pairedMedics', 'pairedAmbulances', 'selectedDate'));
    }

    public function storeBulkPairing(Request $request)
    {
        $request->validate([
            'pairing_type' => 'required|in:driver_medic,driver_ambulance',
            'pairing_date' => 'required|date',
            'start_time' => 'nullable|date_format:H:i',
            'end_time' => 'nullable|date_format:H:i|after:start_time',
            'drivers' => 'required|array|min:1|max:2',
            'drivers.*' => 'exists:drivers,id',
            'medics' => 'required_if:pairing_type,driver_medic|array',
            'medics.*' => 'exists:medics,id',
            'ambulances' => 'required_if:pairing_type,driver_ambulance|array',
            'ambulances.*' => 'exists:ambulances,id',
            'notes' => 'nullable|string|max:500',
        ]);

        $created = 0;
        $errors = [];

        if ($request->pairing_type === 'driver_medic') {
            foreach ($request->drivers as $driverId) {
                foreach ($request->medics as $medicId) {
                    try {
                        // Check for existing pairings before creating
                        // Only check if medic is already paired with a different driver
                        $existingMedicPairing = DriverMedicPairing::where('medic_id', $medicId)
                            ->where('pairing_date', $request->pairing_date)
                            ->where('status', 'active')
                            ->where('driver_id', '!=', $driverId)
                            ->first();

                        if ($existingMedicPairing) {
                            $errors[] = "Medic {$medicId} is already paired with another driver on this date";
                            continue;
                        }

                        // Check if this exact pairing already exists
                        $existingPairing = DriverMedicPairing::where('driver_id', $driverId)
                            ->where('medic_id', $medicId)
                            ->where('pairing_date', $request->pairing_date)
                            ->where('status', 'active')
                            ->first();

                        if ($existingPairing) {
                            $errors[] = "Driver {$driverId} and Medic {$medicId} are already paired on this date";
                            continue;
                        }

                        DriverMedicPairing::create([
                            'driver_id' => $driverId,
                            'medic_id' => $medicId,
                            'pairing_date' => $request->pairing_date,
                            'start_time' => $request->start_time,
                            'end_time' => $request->end_time,
                            'notes' => $request->notes,
                        ]);
                        $created++;
                    } catch (\Exception $e) {
                        $errors[] = "Failed to create pairing for driver {$driverId} and medic {$medicId}: " . $e->getMessage();
                    }
                }
            }
        } else {
            foreach ($request->drivers as $driverId) {
                foreach ($request->ambulances as $ambulanceId) {
                    try {
                        // Check for existing pairings before creating
                        // Only check if ambulance is already paired with a different driver
                        $existingAmbulancePairing = DriverAmbulancePairing::where('ambulance_id', $ambulanceId)
                            ->where('pairing_date', $request->pairing_date)
                            ->where('status', 'active')
                            ->where('driver_id', '!=', $driverId)
                            ->first();

                        if ($existingAmbulancePairing) {
                            $errors[] = "Ambulance {$ambulanceId} is already paired with another driver on this date";
                            continue;
                        }

                        // Check if this exact pairing already exists
                        $existingPairing = DriverAmbulancePairing::where('driver_id', $driverId)
                            ->where('ambulance_id', $ambulanceId)
                            ->where('pairing_date', $request->pairing_date)
                            ->where('status', 'active')
                            ->first();

                        if ($existingPairing) {
                            $errors[] = "Driver {$driverId} and Ambulance {$ambulanceId} are already paired on this date";
                            continue;
                        }

                        $pairing = DriverAmbulancePairing::create([
                            'driver_id' => $driverId,
                            'ambulance_id' => $ambulanceId,
                            'pairing_date' => $request->pairing_date,
                            'notes' => $request->notes,
                        ]);
                        // Sync driver's ambulance for active pairing
                        $driver = Driver::find($driverId);
                        if ($driver) { $driver->ambulance_id = $ambulanceId; $driver->save(); }
                        $created++;
                    } catch (\Exception $e) {
                        $errors[] = "Failed to create pairing for driver {$driverId} and ambulance {$ambulanceId}: " . $e->getMessage();
                    }
                }
            }
        }

        $message = "Successfully created {$created} pairings.";
        if (!empty($errors)) {
            $message .= " Errors: " . implode(', ', $errors);
        }

        return redirect()->route('admin.pairing.index')
            ->with('success', $message);
    }

    public function bulkAction(Request $request)
    {
        $request->validate([
            'action' => 'required|in:complete,cancel',
            'pairing_type' => 'required|in:driver_medic,driver_ambulance',
            'pairing_ids' => 'required|array|min:1',
        ]);

        $updated = 0;
        $status = $request->action === 'complete' ? 'completed' : 'cancelled';

        if ($request->pairing_type === 'driver_medic') {
            // Handle grouped pairings - pairing_ids now contains group keys like "1_2024-01-15"
            foreach ($request->pairing_ids as $groupKey) {
                // Parse the group key to get driver_id and date
                $parts = explode('_', $groupKey);
                if (count($parts) >= 2) {
                    $driverId = $parts[0];
                    $date = implode('-', array_slice($parts, 1)); // Handle dates with dashes
                    
                    $pairings = DriverMedicPairing::where('driver_id', $driverId)
                        ->where('pairing_date', $date)
                        ->where('status', 'active')
                        ->get();
                        
                    foreach ($pairings as $pairing) {
                        $oldData = $pairing->toArray();
                        $pairing->update(['status' => $status]);
                        
                        $this->logPairingAction('driver_medic', $pairing->id, $status, $oldData, $pairing->fresh()->toArray());
                        $updated++;
                    }
                }
            }
        } else {
            // Handle grouped pairings for driver-ambulance
            foreach ($request->pairing_ids as $groupKey) {
                // Parse the group key to get driver_id and date
                $parts = explode('_', $groupKey);
                if (count($parts) >= 2) {
                    $driverId = $parts[0];
                    $date = implode('-', array_slice($parts, 1)); // Handle dates with dashes
                    
                    $pairings = DriverAmbulancePairing::where('driver_id', $driverId)
                        ->where('pairing_date', $date)
                        ->where('status', 'active')
                        ->get();
                        
                    foreach ($pairings as $pairing) {
                        $oldData = $pairing->toArray();
                        $pairing->update(['status' => $status]);
                        
                        $this->logPairingAction('driver_ambulance', $pairing->id, $status, $oldData, $pairing->fresh()->toArray());
                        $updated++;
                        // If completed/cancelled, clear driver's ambulance when pointing to this one
                        $driver = Driver::find($pairing->driver_id);
                        if ($driver && in_array($status, ['completed','cancelled']) && $driver->ambulance_id === $pairing->ambulance_id) {
                            $driver->ambulance_id = null; $driver->save();
                        }
                    }
                }
            }
        }

        return redirect()->route('admin.pairing.index')
            ->with('success', "Successfully {$request->action}d {$updated} pairings.");
    }

    public function groupAction(Request $request)
    {
        $request->validate([
            'action' => 'required|in:complete,cancel',
            'pairing_type' => 'required|in:driver_medic,driver_ambulance',
            'group_key' => 'required|string',
        ]);

        $status = $request->action === 'complete' ? 'completed' : 'cancelled';
        $updated = 0;

        // Parse the group key to get driver_id and date
        $parts = explode('_', $request->group_key);
        if (count($parts) >= 2) {
            $driverId = $parts[0];
            $date = implode('-', array_slice($parts, 1)); // Handle dates with dashes
            
            if ($request->pairing_type === 'driver_medic') {
                $pairings = DriverMedicPairing::where('driver_id', $driverId)
                    ->where('pairing_date', $date)
                    ->where('status', 'active')
                    ->get();
                    
                foreach ($pairings as $pairing) {
                    $oldData = $pairing->toArray();
                    $pairing->update(['status' => $status]);
                    
                    $this->logPairingAction('driver_medic', $pairing->id, $status, $oldData, $pairing->fresh()->toArray());
                    $updated++;
                }
            } else {
                $pairings = DriverAmbulancePairing::where('driver_id', $driverId)
                    ->where('pairing_date', $date)
                    ->where('status', 'active')
                    ->get();
                    
                foreach ($pairings as $pairing) {
                    $oldData = $pairing->toArray();
                    $pairing->update(['status' => $status]);
                    
                    $this->logPairingAction('driver_ambulance', $pairing->id, $status, $oldData, $pairing->fresh()->toArray());
                    $updated++;
                }
            }
        }

        return redirect()->route('admin.pairing.index')
            ->with('success', "Successfully {$request->action}d {$updated} pairings in this group.");
    }

    private function logPairingAction($pairingType, $pairingId, $action, $oldData, $newData)
    {
        PairingLog::create([
            'pairing_type' => $pairingType,
            'pairing_id' => $pairingId,
            'action' => $action,
            'old_data' => $oldData,
            'new_data' => $newData,
            'admin_id' => auth()->id(),
            'notes' => "Pairing {$action} by admin",
        ]);
    }
}
