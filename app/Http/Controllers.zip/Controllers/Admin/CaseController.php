<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\EmergencyCase;
use App\Models\Ambulance;
use App\Models\CaseAmbulance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CaseController extends Controller
{
    /**
     * Store a newly created case.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'contact' => 'required|string|max:255',
            'address' => 'required|string',
            'destination' => 'required|string',
            'type' => 'nullable|string|max:255',
            'priority' => 'required|string|max:255',
            'ambulance_ids' => 'required|array|min:1',
            'ambulance_ids.*' => 'exists:ambulances,id',
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'destination_latitude' => 'required|numeric',
            'destination_longitude' => 'required|numeric',
            'timestamp' => 'required|date',
        ]);

        try {
            return DB::transaction(function () use ($request) {
                // Create the case
                $case = EmergencyCase::create([
                    'status' => 'Pending',
                    'name' => $request->name,
                    'contact' => $request->contact,
                    'type' => $request->type,
                    'address' => $request->address,
                    'destination' => $request->destination,
                    'to_go_to_address' => $request->destination,
                    'to_go_to_latitude' => $request->destination_latitude,
                    'to_go_to_longitude' => $request->destination_longitude,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude,
                    'timestamp' => $request->timestamp,
                    'contact_number' => $request->contact,
                    'driver_accepted' => false,
                    'notification_sent' => false,
                ]);

                // Assign multiple ambulances to the case
                foreach ($request->ambulance_ids as $ambulanceId) {
                    $ambulance = Ambulance::findOrFail($ambulanceId);
                    $driver = $ambulance->driver;

                    // Create case-ambulance assignment
                    CaseAmbulance::create([
                        'case_num' => $case->case_num,
                        'ambulance_id' => $ambulanceId,
                        'driver_accepted' => false,
                        'notification_sent' => true,
                        'assigned_at' => now(),
                    ]);

                    // Update ambulance status to "Out" if not already on a mission
                    if ($ambulance->status !== 'Out') {
                        $ambulance->update([
                            'status' => 'Out',
                            'destination_latitude' => $request->destination_latitude,
                            'destination_longitude' => $request->destination_longitude,
                        ]);
                    }
                }

                // Load the case with its assigned ambulances for response
                $case->load('assignedAmbulances');

                return response()->json([
                    'success' => true,
                    'message' => 'Case created successfully and assigned to ' . count($request->ambulance_ids) . ' ambulance(s)',
                    'case_num' => $case->case_num,
                    'case' => $case->fresh()->load('assignedAmbulances')
                ]);
            });

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error creating case: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display a listing of cases.
     */
    public function index()
    {
        $cases = EmergencyCase::with('ambulance')
            ->where('status', '!=', 'Completed')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // If it's an AJAX request, return JSON
        if (request()->ajax()) {
            return response()->json($cases);
        }
        
        return view('admin.cases.index', compact('cases'));
    }

    /**
     * Get case count for each ambulance
     */
    public function getAmbulanceCaseCounts()
    {
        $caseCounts = EmergencyCase::selectRaw('ambulance_id, COUNT(*) as case_count')
            ->whereNotNull('ambulance_id')
            ->groupBy('ambulance_id')
            ->pluck('case_count', 'ambulance_id');
            
        return response()->json($caseCounts);
    }

    /**
     * Display the specified case.
     */
    public function show(EmergencyCase $case)
    {
        $case->load('ambulance');
        
        // If it's an AJAX request, return JSON
        if (request()->ajax()) {
            return response()->json($case);
        }
        
        return view('admin.cases.show', compact('case'));
    }

    /**
     * Remove the specified case from storage.
     */
    public function destroy(EmergencyCase $case)
    {
        try {
            $caseNum = $case->case_num;
            $case->delete();
            
            return response()->json([
                'success' => true,
                'message' => 'Case deleted successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting case: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update case status (for driver acceptance)
     */
    public function updateStatus(Request $request, EmergencyCase $case)
    {
        $request->validate([
            'status' => 'required|string|in:Pending,Accepted,In Progress,Completed,Cancelled',
            'driver_accepted' => 'boolean',
            'notification_sent' => 'boolean'
        ]);

        try {
            $updateData = [
                'status' => $request->status,
                'driver_accepted' => $request->driver_accepted ?? false,
            ];
            
            if ($request->has('notification_sent')) {
                $updateData['notification_sent'] = $request->notification_sent;
            }
            
            $case->update($updateData);

            return response()->json([
                'success' => true,
                'message' => 'Case status updated successfully',
                'case' => $case->fresh()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error updating case: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get driver notifications for cases
     */
    public function getDriverNotifications(Request $request)
    {
        $driver = auth('driver')->user(); // Get authenticated driver using driver guard
        
        // Get cases assigned to this driver's ambulance through the pivot table
        $caseNums = CaseAmbulance::where('ambulance_id', $driver->ambulance_id)
            ->where('driver_accepted', false)
            ->where('notification_sent', true)
            ->pluck('case_num');
            
        $cases = EmergencyCase::with(['assignedAmbulances'])
            ->whereIn('case_num', $caseNums)
            ->where('status', '!=', 'Completed')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json($cases);
    }

    /**
     * Get all cases for driver (including accepted ones, excluding rejected and completed)
     */
    public function getAllDriverCases(Request $request)
    {
        $driver = auth('driver')->user(); // Get authenticated driver using driver guard
        
        // Get cases assigned to this driver's ambulance through the pivot table
        $caseNums = CaseAmbulance::where('ambulance_id', $driver->ambulance_id)
            ->where('notification_sent', true)
            ->pluck('case_num');
            
        $cases = EmergencyCase::with(['assignedAmbulances'])
            ->whereIn('case_num', $caseNums)
            ->where('status', '!=', 'Rejected')
            ->where('status', '!=', 'Completed')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json($cases);
    }

    /**
     * Driver accepts a case
     */
    public function acceptCase(Request $request, EmergencyCase $case)
    {
        try {
            $driver = auth('driver')->user();
            
            // Check if this case is assigned to the driver's ambulance
            $caseAmbulance = CaseAmbulance::where('case_num', $case->case_num)
                ->where('ambulance_id', $driver->ambulance_id)
                ->first();
                
            if (!$caseAmbulance) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized: Case not assigned to your ambulance'
                ], 403);
            }

            return DB::transaction(function () use ($case, $caseAmbulance, $driver) {
                // Update the specific case-ambulance assignment as accepted
                $caseAmbulance->update([
                    'driver_accepted' => true,
                    'accepted_at' => now(),
                ]);

                // Update the main case status
                $case->update([
                    'status' => 'Accepted',
                    'driver_accepted' => true,
                    'ambulance_id' => $driver->ambulance_id, // Set the accepting ambulance as primary
                    'driver' => $driver->name,
                ]);

                // Remove assignments from other ambulances (cancel other notifications)
                CaseAmbulance::where('case_num', $case->case_num)
                    ->where('ambulance_id', '!=', $driver->ambulance_id)
                    ->delete();

                return response()->json([
                    'success' => true,
                    'message' => 'Case accepted successfully. Other ambulance assignments have been cancelled.',
                    'case' => $case->fresh()->load('assignedAmbulances')
                ]);
            });

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error accepting case: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Driver rejects a case
     */
    public function rejectCase(Request $request, EmergencyCase $case)
    {
        try {
            // Verify the case is assigned to the authenticated driver's ambulance
            $driver = auth('driver')->user();
            if ($case->ambulance_id !== $driver->ambulance_id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized: Case not assigned to your ambulance'
                ], 403);
            }

            $case->update([
                'status' => 'Rejected',
                'driver_accepted' => false,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Case rejected',
                'case' => $case->fresh()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error rejecting case: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Driver completes a case
     */
    public function completeCase(Request $request, EmergencyCase $case)
    {
        try {
            // Verify the case is assigned to the authenticated driver's ambulance
            $driver = auth('driver')->user();
            if ($case->ambulance_id !== $driver->ambulance_id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized: Case not assigned to your ambulance'
                ], 403);
            }

            // Update case status to completed
            $case->update([
                'status' => 'Completed',
                'driver_accepted' => true,
                'completed_at' => now(),
            ]);

            // Update ambulance status back to Available
            $ambulance = $case->ambulance;
            if ($ambulance) {
                $ambulance->update([
                    'status' => 'Available',
                    'destination_latitude' => null,
                    'destination_longitude' => null,
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Case completed successfully',
                'case' => $case->fresh()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error completing case: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get completed cases for logs
     */
    public function getCompletedCases()
    {
        try {
            $cases = EmergencyCase::with('ambulance')
                ->where('status', 'Completed')
                ->orderBy('completed_at', 'desc')
                ->get();

            return response()->json($cases);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to load completed cases',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}