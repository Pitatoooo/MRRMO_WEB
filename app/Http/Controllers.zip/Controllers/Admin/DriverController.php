<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Driver;
use App\Models\Ambulance;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class DriverController extends Controller
{
    public function index(Request $request)
    {
        // Base query
        $query = Driver::with('ambulance');

        // Search by name/email/employee_id
        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function ($sub) use ($q) {
                $sub->where('name', 'like', "%{$q}%")
                    ->orWhere('email', 'like', "%{$q}%")
                    ->orWhere('employee_id', 'like', "%{$q}%");
            });
        }

        // Filter by availability
        if ($request->filled('availability')) {
            $availability = $request->availability;
            if (in_array($availability, ['online', 'offline', 'busy', 'on_break'])) {
                $query->where('availability_status', $availability);
            }
        }

        // Order online drivers first, then newest
        $drivers = $query
            ->orderByRaw("CASE WHEN availability_status = 'online' THEN 0 ELSE 1 END")
            ->orderBy('created_at', 'desc')
            ->get();

        $ambulances = Ambulance::where('status', 'active')->get();

        return view('admin.drivers.index', compact('drivers', 'ambulances'));
    }

    public function show(Driver $driver)
    {
        $driver->load('ambulance', 'driverMedicPairings.medic', 'driverAmbulancePairings.ambulance');
        return view('admin.drivers.show', compact('driver'));
    }

    public function create()
    {
        return view('admin.drivers.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:drivers,email',
            'password' => 'required|min:6|confirmed',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:500',
            'emergency_contact_name' => 'nullable|string|max:255',
            'emergency_contact_phone' => 'nullable|string|max:20',
            'license_number' => 'nullable|string|max:50',
            'license_expiry' => 'nullable|date|after:today',
            'employee_id' => 'nullable|string|max:50|unique:drivers,employee_id',
            'hire_date' => 'nullable|date|before_or_equal:today',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'date_of_birth' => 'nullable|date|before:today',
            'gender' => 'nullable|in:male,female,other',
            'status' => 'required|in:active,inactive,suspended,on_leave',
            'certifications' => 'nullable|array',
            'certifications.*' => 'string|max:255',
            'skills' => 'nullable|array',
            'skills.*' => 'string|max:255',
            'notes' => 'nullable|string|max:1000',
        ]);

        $data = $request->except(['certifications', 'skills', 'certifications_text', 'skills_text', 'ambulance_id']);
        $data['password'] = Hash::make($request->password);
        $data['availability_status'] = 'offline';
        $data['is_available'] = true;

        // Handle certifications and skills arrays
        if ($request->has('certifications_text')) {
            $certifications = array_filter(array_map('trim', explode("\n", $request->certifications_text)));
            $data['certifications'] = $certifications;
        }

        if ($request->has('skills_text')) {
            $skills = array_filter(array_map('trim', explode("\n", $request->skills_text)));
            $data['skills'] = $skills;
        }

        // Handle photo upload
        if ($request->hasFile('photo')) {
            $photo = $request->file('photo');
            $filename = time() . '_' . Str::slug($request->name) . '.' . $photo->getClientOriginalExtension();
            $photo->storeAs('driver-photos', $filename, 'public');
            $data['photo'] = $filename;
        }

        Driver::create($data);

        return redirect()->route('admin.drivers.index')->with('success', 'Driver created successfully!');
    }

    public function edit(Driver $driver)
    {
        $ambulances = Ambulance::where('status', 'active')->get();
        return view('admin.drivers.edit', compact('driver', 'ambulances'));
    }

    public function update(Request $request, Driver $driver)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:drivers,email,' . $driver->id,
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:500',
            'emergency_contact_name' => 'nullable|string|max:255',
            'emergency_contact_phone' => 'nullable|string|max:20',
            'license_number' => 'nullable|string|max:50',
            'license_expiry' => 'nullable|date',
            'employee_id' => 'nullable|string|max:50|unique:drivers,employee_id,' . $driver->id,
            'hire_date' => 'nullable|date|before_or_equal:today',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'date_of_birth' => 'nullable|date|before:today',
            'gender' => 'nullable|in:male,female,other',
            'status' => 'required|in:active,inactive,suspended,on_leave',
            'availability_status' => 'required|in:online,offline,busy,on_break',
            'ambulance_id' => 'nullable|exists:ambulances,id',
            'certifications' => 'nullable|array',
            'certifications.*' => 'string|max:255',
            'skills' => 'nullable|array',
            'skills.*' => 'string|max:255',
            'notes' => 'nullable|string|max:1000',
        ]);

        $data = $request->except(['password', 'photo', 'certifications', 'skills', 'certifications_text', 'skills_text']);

        // Handle password update
        if ($request->filled('password')) {
            $request->validate(['password' => 'min:6|confirmed']);
            $data['password'] = Hash::make($request->password);
        }

        // Handle certifications and skills arrays
        if ($request->has('certifications_text')) {
            $certifications = array_filter(array_map('trim', explode("\n", $request->certifications_text)));
            $data['certifications'] = $certifications;
        }

        if ($request->has('skills_text')) {
            $skills = array_filter(array_map('trim', explode("\n", $request->skills_text)));
            $data['skills'] = $skills;
        }

        // Handle photo upload
        if ($request->hasFile('photo')) {
            // Delete old photo
            if ($driver->photo) {
                Storage::disk('public')->delete('driver-photos/' . $driver->photo);
            }
            
            $photo = $request->file('photo');
            $filename = time() . '_' . Str::slug($request->name) . '.' . $photo->getClientOriginalExtension();
            $photo->storeAs('driver-photos', $filename, 'public');
            $data['photo'] = $filename;
        }

        $driver->update($data);

        return redirect()->route('admin.drivers.index')->with('success', 'Driver updated successfully!');
    }

    public function destroy(Driver $driver)
    {
        // Delete photo if exists
        if ($driver->photo) {
            Storage::disk('public')->delete('driver-photos/' . $driver->photo);
        }

        $driver->delete();

        return redirect()->route('admin.drivers.index')->with('success', 'Driver deleted successfully!');
    }

    public function updateStatus(Request $request, Driver $driver)
    {
        $request->validate([
            'status' => 'required|in:active,inactive,suspended,on_leave',
            'availability_status' => 'required|in:online,offline,busy,on_break',
        ]);

        $driver->update([
            'status' => $request->status,
            'availability_status' => $request->availability_status,
            'last_seen_at' => now()
        ]);

        return back()->with('success', 'Driver status updated successfully!');
    }

    public function toggleAvailability(Driver $driver)
    {
        $newStatus = $driver->is_available ? 'offline' : 'online';
        $driver->setAvailabilityStatus($newStatus);

        return back()->with('success', 'Driver availability updated successfully!');
    }
}
