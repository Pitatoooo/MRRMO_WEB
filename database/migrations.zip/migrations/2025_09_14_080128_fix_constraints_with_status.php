<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class FixConstraintsWithStatus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Remove the current constraints that don't consider status
        Schema::table('driver_medic_pairings', function (Blueprint $table) {
            $table->dropUnique('unique_medic_date');
        });

        Schema::table('driver_ambulance_pairings', function (Blueprint $table) {
            $table->dropUnique('unique_ambulance_date');
        });

        // Add partial unique constraints that only apply to active pairings
        // For PostgreSQL, we need to use a partial unique index
        DB::statement('CREATE UNIQUE INDEX unique_medic_date_active ON driver_medic_pairings (medic_id, pairing_date) WHERE status = \'active\'');
        DB::statement('CREATE UNIQUE INDEX unique_ambulance_date_active ON driver_ambulance_pairings (ambulance_id, pairing_date) WHERE status = \'active\'');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Drop the partial unique indexes
        DB::statement('DROP INDEX IF EXISTS unique_medic_date_active');
        DB::statement('DROP INDEX IF EXISTS unique_ambulance_date_active');

        // Restore the original constraints
        Schema::table('driver_medic_pairings', function (Blueprint $table) {
            $table->unique(['medic_id', 'pairing_date'], 'unique_medic_date');
        });

        Schema::table('driver_ambulance_pairings', function (Blueprint $table) {
            $table->unique(['ambulance_id', 'pairing_date'], 'unique_ambulance_date');
        });
    }
}
