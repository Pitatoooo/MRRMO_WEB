<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class FixPairingConstraintsLogic extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Remove the incorrect constraints
        Schema::table('driver_medic_pairings', function (Blueprint $table) {
            $table->dropUnique('unique_driver_date_medic');
            $table->dropUnique('unique_medic_date_driver');
        });

        Schema::table('driver_ambulance_pairings', function (Blueprint $table) {
            $table->dropUnique('unique_driver_date_ambulance');
            $table->dropUnique('unique_ambulance_date_driver');
        });

        // Add correct constraints
        // For driver-medic: Only prevent medic from being paired with multiple drivers
        Schema::table('driver_medic_pairings', function (Blueprint $table) {
            $table->unique(['medic_id', 'pairing_date'], 'unique_medic_date');
        });

        // For driver-ambulance: Only prevent ambulance from being paired with multiple drivers
        Schema::table('driver_ambulance_pairings', function (Blueprint $table) {
            $table->unique(['ambulance_id', 'pairing_date'], 'unique_ambulance_date');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Remove the correct constraints
        Schema::table('driver_medic_pairings', function (Blueprint $table) {
            $table->dropUnique('unique_medic_date');
        });

        Schema::table('driver_ambulance_pairings', function (Blueprint $table) {
            $table->dropUnique('unique_ambulance_date');
        });

        // Restore the original constraints
        Schema::table('driver_medic_pairings', function (Blueprint $table) {
            $table->unique(['driver_id', 'pairing_date'], 'unique_driver_date_medic');
            $table->unique(['medic_id', 'pairing_date'], 'unique_medic_date_driver');
        });

        Schema::table('driver_ambulance_pairings', function (Blueprint $table) {
            $table->unique(['driver_id', 'pairing_date'], 'unique_driver_date_ambulance');
            $table->unique(['ambulance_id', 'pairing_date'], 'unique_ambulance_date_driver');
        });
    }
}
